If you want to help translate Listary, please visit: http://www.listary.com/languages
Send an email to support@listary.com if you have any questions